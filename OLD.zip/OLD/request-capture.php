<?
	if(isset($_POST['scontact'])){

		$name = $_POST["name"];
		$remail = $_POST["remail"];
		$subject = $_POST["subject"];
		$desc = $_POST["desc"];

				$Idto= "<getacook@gmail.com>";
				$Idfrom=  $_POST["remail"];

				$messages = "Dear Webmaster,\r\n";
				$messages .="\r\n";
				
				$messages .= "".$name." with following details is requesting to Contact, Here are the details of User";
				$messages .="\r\n";
				$messages .= "\r\n";

				$messages .= "Email : ".$remail."";
				$messages .="\r\n";
				$messages .= "\r\n";

				$messages .= "Subject : ".$subject."";
				$messages .="\r\n";
				$messages .= "\r\n";

				$messages .= "Message : ".$desc."";
				$messages .="\r\n";
				$messages .= "\r\n";

				$messages .= "Best Regards" ."\r\n";
				$messages .= "Get a Cook Team" ."\r\n";
				$messages .= "[www.getacook.in]";

				$headers  = 'MIME-Version: 1.0' . "\r\n";
				$headers = "From: " . $Idfrom . "\n" . "Return-Path: " . $Idfrom . "\n" . "Reply-To: " . $Idfrom . "\n";
				$m2=mail($Idto,$subject,$messages,$headers);
				
		echo "<script language=\"JavaScript\">\n";  
		echo "alert(\"Thank you for contacting us, One of Our Executive will get back to you Shortly.\");\n";				 		echo "window.location = \"index.html\";\n"; 
		echo "</script>";

}
?>
